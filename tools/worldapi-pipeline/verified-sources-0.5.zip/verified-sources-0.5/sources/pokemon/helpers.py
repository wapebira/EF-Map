"""Pokemon pipeline helpers"""
